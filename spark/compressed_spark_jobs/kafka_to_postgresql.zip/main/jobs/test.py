from pyspark.sql import SparkSession, DataFrame
import IP2Location
from pyspark.sql import functions as f
from pyspark.sql.functions import (
    from_unixtime, date_trunc, date_format, hour, dayofweek, dayofmonth, 
    dayofyear, weekofyear, month, quarter, year, col, expr, concat, lit, md5
)
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

view_event_schema = StructType([
    StructField("_id", StringType(), True),
    StructField("api_version", StringType(), True),
    StructField("collection", StringType(), True),
    StructField("current_url", StringType(), True),
    StructField("device_id", StringType(), True),
    StructField("email", StringType(), True),
    StructField("ip", StringType(), True),
    StructField("local_time", StringType(), True),
    StructField("product_id", StringType(), True),
    StructField("referrer_url", StringType(), True),
    StructField("store_id", StringType(), True),
    StructField("time_stamp", IntegerType(), True),
    StructField("user_agent", StringType(), True),
    StructField("id", StringType(), True)
])

def process_dim_time(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("time_stamp", from_unixtime(col("time_stamp")))
        .withColumn("hourly_timestamp", date_trunc("hour", col("time_stamp")))
        .withColumn("time_id", date_format(col("hourly_timestamp"), "yyyyMMddHH").cast("integer"))
        .withColumn("hour", hour(col("hourly_timestamp")))
        .withColumn("day_of_week", dayofweek(col("hourly_timestamp")))
        .withColumn("is_weekend", col("day_of_week").isin([1, 7]))
        .withColumn("day_of_month", dayofmonth(col("hourly_timestamp")))
        .withColumn("day_of_year", dayofyear(col("hourly_timestamp")))
        .withColumn("week_of_month", expr("cast(ceil(day_of_month / 7.0) as int)"))
        .withColumn("week_of_year", weekofyear(col("hourly_timestamp")))
        .withColumn("month_of_year", month(col("hourly_timestamp")))
        .withColumn("quarter", quarter(col("hourly_timestamp")))
        .withColumn("year", year(col("hourly_timestamp")))
        .select(
            "time_id",
            col("hourly_timestamp").alias("timestamp"),
            "hour",
            "day_of_week",
            "is_weekend",
            "day_of_month",
            "day_of_year",
            "week_of_month",
            "week_of_year",
            "month_of_year",
            "quarter",
            "year"
        )
        .dropDuplicates(["time_id"])
    )
    
def process_dim_store(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("store_name", concat(lit("store_"), col("store_id")))
        .select(
            col("store_id").cast("integer"),
            "store_name"
        )
        .dropDuplicates(["store_id"])
    )

import user_agents
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType


@udf(StringType())
def get_browser(user_agent: str) -> str:
    try:
        ua = user_agents.parse(user_agent)
        return ua.browser.family or "Unknown"
    except Exception as e:
        return "Unknown"
    

@udf(StringType())
def get_os(user_agent: str) -> str:
    try:
        ua = user_agents.parse(user_agent)
        return ua.os.family or "Unknown"
    except Exception as e:
        return "Unknown"


def write_to_postgres(df, epoch_id, table):
    import psycopg2
    from psycopg2.extras import execute_values
    try:
        print(f"Processing batch {epoch_id} for table {table}")
        
        rows = df.collect()
        conn = psycopg2.connect(
            host="postgres-data",
            port=5432,
            dbname="glamira",
            user="postgres",
            password="postgres"
        )
        conn.autocommit = False
        cursor = conn.cursor()

        columns = df.columns
        data = [tuple(row) for row in rows]
        if table == "fact_view_event":
            conflict_column = "event_id"
        else:
            conflict_column = "_".join(table.split("_")[1::])+"_id"        
        
        execute_values(
            cursor,
            f"INSERT INTO {table} ({','.join(columns)}) VALUES %s ON CONFLICT ({conflict_column}) DO NOTHING",
            data
        )

        conn.commit()
        print(f"Successfully wrote batch {epoch_id} to {table}")

    except Exception as e:
        print(f"Error writing to PostgreSQL: {e}")
        if conn:
            conn.rollback()
    finally:
        if conn:
            cursor.close()
            conn.close()

def process_dim_browser(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("browser", get_browser(col("user_agent")))
        .withColumn("browser_id", md5(col("browser")))
        .select(
            "browser_id",
            "browser"
        )
        .dropDuplicates(["browser_id"])
    )


def process_dim_os(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("os", get_os(col("user_agent")))
        .withColumn("os_id", md5(col("os")))
        .select(
            "os_id",
            "os"
        )
        .dropDuplicates(["os_id"])
    )
@udf(StringType())
def get_country(ip: str) -> str:
    if not ip or ip in ("", "unknown", "0.0.0.0"):
        return "Unknown"
    try:
        db = IP2Location.IP2Location("../resource/IP-COUNTRY-REGION-CITY.BIN")
        record = db.get_all(ip)
        return record.country_long or "Unknown"
    except FileNotFoundError as e:
        raise FileNotFoundError(
            "IP2Location database file not found. Please ensure the file exists at 'main/resource/IP-COUNTRY-REGION-CITY.BIN'."
        ) from e
    
@udf(StringType())
def get_region(ip: str) -> str:
    if not ip or ip in ("", "unknown", "0.0.0.0"):
        return "Unknown"
    try:
        db = IP2Location.IP2Location("../resource/IP-COUNTRY-REGION-CITY.BIN")
        record = db.get_all(ip)
        return record.region or "Unknown"
    except FileNotFoundError as e:
        raise FileNotFoundError(
            "IP2Location database file not found. Please ensure the file exists at 'main/resource/IP-COUNTRY-REGION-CITY.BIN'."
        ) from e

@udf(StringType())
def get_city(ip: str) -> str:
    if not ip or ip in ("", "unknown", "0.0.0.0"):
        return "Unknown"
    try:
        db = IP2Location.IP2Location("../resource/IP-COUNTRY-REGION-CITY.BIN")
        record = db.get_all(ip)
        return record.city or "Unknown"
    except FileNotFoundError as e:
        raise FileNotFoundError(
            "IP2Location database file not found. Please ensure the file exists at 'main/resource/IP-COUNTRY-REGION-CITY.BIN'."
        ) from e

def process_dim_location(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("city", get_city(col("ip")))
        .withColumn("region", get_region(col("ip")))
        .withColumn("country", get_country(col("ip")))
        .withColumn("location_id", md5(concat(col("city"), col("region"), col("country"))))
        .select(
            "location_id",
            "city",
            "region",
            "country"
        )
        .dropDuplicates(["location_id"])
    )


def process_dim_referrer_url(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("referrer_url_id", md5(col("referrer_url")))
        .select(
            "referrer_url_id",
            "referrer_url"
        )
        .dropDuplicates(["referrer_url_id"])
    )
    
import re

@udf(StringType())
def get_product_name(url: str) -> str:
    if not url:
        return "Unknown"
    
    try:
        match = re.search(r'(?:glamira-)?([^/?]+?)(?:-sku|\.html|$)', url)
        if match:
            product = match.group(1)
            return product.replace("-", " ").title()
        return "Unknown"
    except Exception:
        return "Unknown"

def process_dim_product(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("product_name", get_product_name(col("current_url")))
        .select(
            "product_id",
            "product_name"
        )
        .dropDuplicates(["product_id"])
    )

def process_dim_store(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("store_name", concat(lit("store_"), col("store_id")))
        .select(
            "store_id",
            "store_name"
        )
        .dropDuplicates(["store_id"])
    )

def process_fact_view_event(raw_df: DataFrame) -> DataFrame:
    return (
        raw_df
        .withColumn("time_stamp", from_unixtime("time_stamp"))
        .withColumn("hourly_timestamp", date_trunc("hour", "time_stamp"))
        .withColumn("time_id", date_format("hourly_timestamp", "yyyyMMddHH"))
        .withColumn("city", get_city(col("ip")))
        .withColumn("region", get_region(col("ip")))
        .withColumn("country", get_country(col("ip")))
        .withColumn("location_id", md5(concat(col("city"), col("region"), col("country"))))
        .withColumn("referrer_url_id", md5(col("referrer_url")))
        .withColumn("os", get_os(col("user_agent")))
        .withColumn("os_id", md5(col("os")))
        .withColumn("browser", get_browser(col("user_agent")))
        .withColumn("browser_id", md5(col("browser")))
        .select(
            col("_id").alias("event_id"),
            col("collection").alias("event_type"),
            "time_id",
            "product_id",
            "store_id",
            "location_id",
            "referrer_url_id",
            "browser_id",
            "os_id"
        )
    )


def create_query(df, table):
    return (df.writeStream
            .foreachBatch(lambda df, epoch_id: write_to_postgres(df, epoch_id, table))
            .outputMode("append")
            .trigger(processingTime='30 seconds')
            .start())

def main():
    
    spark = SparkSession.builder \
        .appName("ProductViewsStreaming") \
        .config("spark.sql.streaming.forceDeleteTempCheckpointLocation", "true") \
        .getOrCreate()
    
    spark.sparkContext.setLogLevel("WARN")
    
    kafka_options = {
        "kafka.bootstrap.servers": "kafka-0:9092,kafka-1:9092,kafka-2:9092",
        "kafka.security.protocol": "SASL_PLAINTEXT",
        "kafka.sasl.mechanism": "PLAIN",
        "kafka.sasl.jaas.config": 
            'org.apache.kafka.common.security.plain.PlainLoginModule required '
            'username="kafka" '
            'password="admin";',
        "subscribe": "product_views",
        "startingOffsets": "latest",
        "failOnDataLoss": "false"
    }
    
    kafka_df = (spark.readStream
                .format("kafka")
                .options(**kafka_options)
                .load())
    
    parsed_df = kafka_df.select(
        f.from_json(f.col("value").cast("string"), view_event_schema).alias("data")
    ).select("data.*")
    
    dim_time = process_dim_time(parsed_df)
    dim_browser = process_dim_browser(parsed_df)
    dim_os = process_dim_os(parsed_df)
    dim_location = process_dim_location(parsed_df)
    dim_product = process_dim_product(parsed_df)
    dim_referrer_url = process_dim_referrer_url(parsed_df)
    dim_store = process_dim_store(parsed_df)
    fact_view_event = process_fact_view_event(parsed_df)
    
    dim_time_query = create_query(dim_time, "dim_time")
    dim_browser_query = create_query(dim_browser, "dim_browser")
    dim_os_query = create_query(dim_os, "dim_os")
    dim_location_query = create_query(dim_location, "dim_location")
    dim_product_query = create_query(dim_product, "dim_product")
    dim_referrer_url_query = create_query(dim_referrer_url, "dim_referrer_url")
    dim_store_query = create_query(dim_store, "dim_store")
    fact_view_event_query = create_query(fact_view_event, "fact_view_event")

    print("Starting streaming queries...")
    
    try:
        dim_time_query.awaitTermination()
        dim_browser_query.awaitTermination()
        dim_os_query.awaitTermination()
        dim_location_query.awaitTermination()
        dim_product_query.awaitTermination()
        dim_referrer_url_query.awaitTermination()
        dim_store_query.awaitTermination()
        fact_view_event_query.awaitTermination()
    except KeyboardInterrupt:
        print("Stopping streaming queries...")
        dim_time_query.stop()
        dim_browser_query.stop()
        dim_os_query.stop()
        dim_location_query.stop()
        dim_product_query.stop()
        dim_referrer_url_query.stop()
        dim_store_query.stop()
        fact_view_event_query.stop()
        spark.stop()

if __name__ == "__main__":
    main()